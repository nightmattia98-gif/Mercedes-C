# Mercedes Cockpit W204 — progetto Android

Questo progetto impacchetta la versione HTML del cockpit in un'app Android installabile. Si apre come app a schermo intero, in orizzontale, senza avviare Chrome. L'interfaccia viene visualizzata da Android WebView integrato nel processo dell'app; non è una riscrittura completa dell'interfaccia in Kotlin/Jetpack Compose.

## Contenuto
- `app/src/main/assets/index.html`: cockpit HTML autonomo con immagine incorporata, pagina Pianifica tratta e storico.
- `app/src/main/java/.../MainActivity.kt`: contenitore Android a schermo intero.
- Nessun permesso Internet richiesto. I dati vengono conservati nel `localStorage` della WebView sul dispositivo.

## Creare l'APK con Android Studio
1. Installa Android Studio su un PC/Mac e, dall'SDK Manager, installa Android SDK Platform 35 e Android Build Tools compatibili.
2. Estrai la cartella `MercedesCockpitAndroid`.
3. In Android Studio scegli **Open** e seleziona questa cartella (quella che contiene `settings.gradle.kts`).
4. Attendi la sincronizzazione Gradle.
5. Vai su **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. L'APK di debug sarà normalmente in `app/build/outputs/apk/debug/app-debug.apk`.
7. Copia l'APK sul tablet e aprilo per installarlo. Se Android lo richiede, autorizza l'installazione da quella sorgente.

Per distribuire l'app fuori dal tuo tablet, crea una build firmata da **Build → Generate Signed Bundle / APK** e conserva con cura la chiave di firma.

## Nota importante
In questo ambiente non è installato Android SDK/Gradle, quindi qui posso fornire il progetto pronto da aprire e compilare, ma non un APK già compilato e verificato. La WebView è integrata nell'APK e non apre Chrome. Una versione completamente nativa, in cui tutte le schermate sono ricostruite in Kotlin/Jetpack Compose, sarebbe un progetto di sviluppo distinto.
