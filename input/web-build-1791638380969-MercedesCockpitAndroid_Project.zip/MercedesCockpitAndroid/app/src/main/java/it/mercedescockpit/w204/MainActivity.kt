package it.mercedescockpit.w204

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var cockpit: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )

        cockpit = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(6, 9, 12))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true // localStorage conserva i registri sul tablet
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.setSupportZoom(false)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
        }
        setContentView(cockpit)
        if (savedInstanceState == null) {
            cockpit.loadUrl("file:///android_asset/index.html")
        } else {
            cockpit.restoreState(savedInstanceState)
        }

    }

    @Deprecated("Deprecated in Android API; retained for compatibility with the no-dependency project")
    override fun onBackPressed() {
        if (::cockpit.isInitialized) {
            cockpit.evaluateJavascript(
                "(function(){var a=document.querySelector('.view.active');if(a&&a.id!=='home'){show('home');} })()",
                null
            )
        } else {
            super.onBackPressed()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        cockpit.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        if (::cockpit.isInitialized) cockpit.destroy()
        super.onDestroy()
    }
}
